
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:task_app/layout/app_layout.dart';
import 'package:task_app/modules/auth/login_screen.dart';
import 'package:task_app/tools/component/constants.dart';
import 'package:task_app/tools/locale/cache_helper.dart';
import 'package:task_app/tools/locale/dio_helper.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await CacheHelper.init();   // initial Stored local
  DioHelper.init();           // initial Dio Api class

  // await NotificationService().init();

  token = CacheHelper.getData(key: 'token');
  isDarkTheme = CacheHelper.getData(key: 'isDarkTheme')??false;
  lang = CacheHelper.getData(key: 'lang')??Platform.localeName.substring(0,2);


  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      onInit: (){initializeDateFormatting('ar', null);},
          debugShowCheckedModeBanner: false,
          title: 'Task App',
          theme: defaultTheme(context),
          home: (token != null) ?  AppLayout():LoginScreen(),
        );
  }
}
