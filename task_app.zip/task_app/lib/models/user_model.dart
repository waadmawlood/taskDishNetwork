// To parse this JSON data, do
//
//     final userModel = userModelFromJson(jsonString);

import 'dart:convert';

UserModel userModelFromJson(String str) => UserModel.fromJson(json.decode(str));

String userModelToJson(UserModel data) => json.encode(data.toJson());

class UserModel {
  UserModel({
    this.success,
    this.status,
    this.msg,
    this.data,
  });

  bool success;
  int status;
  String msg;
  User data;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
    success: json["success"],
    status: json["status"],
    msg: json["msg"],
    data: User.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "status": status,
    "msg": msg,
    "data": data.toJson(),
  };
}

class User {
  User({
    this.id,
    this.name,
    this.username,
    this.image,
    this.typeId,
    this.createdAt,
    this.updatedAt,
    this.roles,
  });

  int id;
  String name;
  String username;
  String image;
  int typeId;
  String createdAt;
  String updatedAt;
  List<Role> roles;

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    name: json["name"],
    username: json["username"],
    image: json["image"],
    typeId: json["type_id"],
    createdAt: json["created_at"],
    updatedAt: json["updated_at"],
    roles: List<Role>.from(json["roles"].map((x) => Role.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "username": username,
    "image": image,
    "type-id": typeId,
    "created_at": createdAt,
    "updated_at": updatedAt,
    "roles": List<dynamic>.from(roles.map((x) => x.toJson())),
  };
}

class Role {
  Role({
    this.id,
    this.name,
    this.pivot,
  });

  int id;
  String name;
  Pivot pivot;

  factory Role.fromJson(Map<String, dynamic> json) => Role(
    id: json["id"],
    name: json["name"],
    pivot: Pivot.fromJson(json["pivot"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "pivot": pivot.toJson(),
  };
}

class Pivot {
  Pivot({
    this.userId,
    this.roleId,
  });

  int userId;
  int roleId;

  factory Pivot.fromJson(Map<String, dynamic> json) => Pivot(
    userId: json["user_id"],
    roleId: json["role_id"],
  );

  Map<String, dynamic> toJson() => {
    "user_id": userId,
    "role_id": roleId,
  };
}
