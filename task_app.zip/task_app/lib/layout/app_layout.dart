import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_app/get_x/app_controller.dart';
import 'package:task_app/tools/component/constants.dart';



class AppLayout extends StatefulWidget {

  @override
  _AppLayoutState createState() => _AppLayoutState();
}

class _AppLayoutState extends State<AppLayout> {
  @override
  Widget build(BuildContext context) {
    AppViewModel appController = Get.put(AppViewModel());
    final icons = <BottomNavigationBarItem>[
      BottomNavigationBarItem(icon: Icon(Icons.home), title: Text("Home")),
      BottomNavigationBarItem(icon: Icon(Icons.settings), title: Text("Setting")),
    ];

    return Scaffold(
        appBar: AppBar(
          title: Obx(()=> Row(
            children: [
              CircleAvatar(backgroundColor: typesUserColor[(appController.auth.value.data.typeId??1) -1]??colorText1,),
              Text('   ' + appController.auth.value.data.name??'User')
            ],
          )),
          actions: [
            IconButton(icon: Icon(Icons.search), onPressed: (){}),
          ],
        ),
        body: GetX<AppViewModel>(
          init: AppViewModel(),
            builder: (value)=> value.pages[value.currentTabIndex.value]
        ),
        bottomNavigationBar: GetX<AppViewModel>(
            builder: (value)=> BottomNavigationBar(
              items: icons,
              currentIndex: value.currentTabIndex.value ,
              type: BottomNavigationBarType.fixed,
              onTap: (int index) {
                value.changeTabIndex(index);
              },
            ),
        ),
      );
  }
}
