import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_app/get_x/app_controller.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';
import 'package:task_app/tools/component/functions.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    AppViewModel appController = Get.put(AppViewModel());
    return RefreshIndicator(
      onRefresh: () async {
        appController.getFirstPosts(token);
      },
      child: Obx(
        () => appController.posts.value.length == 0
            ? Center(
                child: CircularProgressIndicator(),
              )
            : ListView.separated(
                itemBuilder: (context, i) => Container(
                      width: double.infinity,
                      padding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: colorSuccess,
                                backgroundImage: AssetImage(userImageDefault),
                              ),
                              const SizedMedia(
                                w: 6,
                              ),
                              DefaultText('Dish Network'
                                  ),
                              Spacer(),
                              DefaultText(
                                CustomFunctions.readTimestamp(DateTime.parse(appController.posts.value[i].createdAt).millisecondsSinceEpoch).toString(),
                              ),
                            ],
                          ),
                          const SizedMedia(
                            h: 4,
                          ),
                          CachedNetworkImage(
                            imageUrl: appController.posts.value[i].image,
                            placeholder: (context, url) => Center(child: new CircularProgressIndicator(),) ,
                            errorWidget: (context, url, error) => new Icon(Icons.error),
                            fit: BoxFit.cover,
                            width: double.infinity,
                            height: h100(context, 45),
                          ),
                          DefaultText(
                            appController.posts.value[i].id.toString() + " : " +
                                appController.posts.value[i].name,
                            weight: FontWeight.bold,
                            size: h100(context, 4),
                          ),
                          Row(
                            children: [
                              CircleAvatar(
                                backgroundColor: typesUserColor[appController.auth.value.data.typeId-1]??colorText1,
                                radius: h100(context, 3),
                              ),
                              DefaultText(
                                "     " + appController.posts.value[i].price.toString() + " \$",
                                weight: FontWeight.bold,
                                size: h100(context, 4),
                                color: colorSuccess,
                              ),

                              Spacer(),
                              CircleAvatar(
                                backgroundColor: appController.posts.value[i].active == 1 ? colorSuccess : colorDanger,
                                radius: h100(context, 2.5),
                              ),
                            ],
                          )
                        ],
                      ),
                    ),
                separatorBuilder: (context, index) => const Divider(),
                itemCount: appController.posts.value.length,
                ),
      ),
    );
  }
}
