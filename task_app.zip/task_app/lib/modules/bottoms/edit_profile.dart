import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_app/get_x/app_controller.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';

class EditScreen extends StatelessWidget {

  var nameText = new TextEditingController();
  var userNameText =new TextEditingController();
  var passwordText = new TextEditingController();


  @override
  Widget build(BuildContext context) {
    AppViewModel appViewModel = Get.put(AppViewModel());

    nameText.text = appViewModel.auth.value.data.name;
    userNameText.text = appViewModel.auth.value.data.username;

    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(width: double.infinity, height: h100S(context,3),),
                  Obx(()=>Stack(
                    alignment: Alignment.bottomLeft,
                    children: [
                      WidgetRadiusAndShadow(
                        child: appViewModel.fileImage.value == null ?
                        CachedNetworkImage(
                          imageUrl: appViewModel.auth.value.data.image,
                          width: w100(context, 70),
                          height: w100(context, 70),
                          fit: BoxFit.cover,
                        ) :
                        Image.file(appViewModel.fileImage.value,
                          width: w100(context, 70),
                          height: w100(context, 70),
                          fit: BoxFit.cover,
                        ),
                      ),

                      appViewModel.fileImage.value == null ?
                      IconButton(
                        icon: Icon(Icons.camera_alt),
                        onPressed: (){
                          appViewModel.getImageFile();
                        },
                        iconSize: h100S(context,5),
                      ) :
                      IconButton(
                        icon: Icon(Icons.delete_forever),
                        onPressed: (){
                          appViewModel.emptyImage();
                        },
                        color: colorDanger,
                        iconSize: h100S(context,5),
                      ),
                    ],
                  ),
                ),





                const Divider(),

                DefaultTextField(
                  controller: nameText,
                  colorHint: colorText1.withOpacity(0.4),
                  color: colorText1,
                  hintText: 'Name ....',
                  prefixIcon: Icons.text_fields,
                  borderRadius: 10,
                ),
                const Divider(),
                DefaultTextField(
                  controller: userNameText,
                  colorHint: colorText1.withOpacity(0.4),
                  color: colorText1,
                  hintText: 'username ....',
                  prefixIcon: Icons.person_pin,
                  borderRadius: 10,
                ),
                const Divider(),
                DefaultTextField(
                  controller: passwordText,
                  colorHint: colorText1.withOpacity(0.4),
                  color: colorText1,
                  hintText: 'password ....',
                  prefixIcon: Icons.lock_outline,
                  borderRadius: 10,
                ),
                const Divider(),
                appViewModel.isLoading.value ?
                    CircularProgressIndicator():
                DefaultTextButton(
                    onPressed: () {
                      appViewModel.updateUser(nameText.text,userNameText.text,passwordText.text);
                    },
                    label: 'Update',
                  radius: 10,
                ),


              ],
            ),
          ),
        ),
    );
  }
}