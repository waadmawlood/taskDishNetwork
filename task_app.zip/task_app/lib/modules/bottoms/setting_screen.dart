import 'dart:ui';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:task_app/get_x/app_controller.dart';
import 'package:task_app/modules/bottoms/edit_profile.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';

class SettingScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    AppViewModel appController = Get.put(AppViewModel());

      return Directionality(
          textDirection: TextDirection.ltr,
          child: Stack(
            children: [
              Opacity(
                opacity: 0.5,
                child: Container(
                  width: size.width,
                  height: size.height,
                  child: Image.asset(
                    'assets/images/background-setting.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              Container(
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                      sigmaY: 1, sigmaX: 12, tileMode: TileMode.clamp),
                  child: SingleChildScrollView(
                    child: Obx(()=>Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [

                        SizedMedia(h: h100(context,5),),
                        WidgetRadiusAndShadow(
                          child: CachedNetworkImage(
                            imageUrl: appController.auth.value.data.image,
                            width: h100(context,25),
                            height: h100(context,25),
                          ),

                          raduis: size.height,
                          blurRadius: 10,
                          color: colorText1.withOpacity(0.4),
                          spreadRadius: 1,
                        ),


                        if(appController.auth.value.data != null)
                          Container(
                            height: h100(context,10),
                            child: FittedBox(
                              fit: BoxFit.fitHeight,
                              child: DefaultText(
                                appController.auth.value.data.name,
                                weight: FontWeight.bold,
                              ),
                            ),
                          ),

                        if(appController.auth.value.data != null)
                          Container(
                            height: h100(context,10),
                            child: FittedBox(
                              fit: BoxFit.fitHeight,
                              child: DefaultText(
                                typesUser[appController.auth.value.data.typeId-1]??'Normal',
                                weight: FontWeight.bold,
                              ),
                            ),
                          ),


                        if(appController.auth.value.data != null)
                          Container(
                            height: h100(context,10),
                            child: FittedBox(
                              fit: BoxFit.fitHeight,
                              child: DefaultText(
                                appController.auth.value.data.username,
                                weight: FontWeight.bold,
                              ),
                            ),
                          ),


                        SizedMedia(h: h100(context,5),),
                        DefaultTextButton(
                          onPressed: (){
                            Get.to(EditScreen());
                          },
                          label: 'Edit Profile',
                          icon: Icons.emoji_people_rounded,
                          background: colorPrimary,
                          width: w100(context,80),
                          height: h100(context,15),
                          fontSize: h100(context,4),
                          iconSize: h100(context,4),
                        ),

                        SizedMedia(h: h100(context,5),),
                        DefaultTextButton(
                          onPressed: (){
                            appController.logout();
                          },
                          label: 'LOGOUT',
                          icon: Icons.logout,
                          background: colorDanger,
                          width: w100(context,100),
                          height: h100(context,13),
                          fontSize: h100(context,4),
                          iconSize: h100(context,4),
                        ),

                      ],
                    ),)
                  ),
                ),
              ),
            ],
          ));
  }
}
