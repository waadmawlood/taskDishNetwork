import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:ui';
import 'package:task_app/get_x/auth_controller.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';

class RegisterScreen extends StatelessWidget {
  var nameTxt = TextEditingController();
  var emailTxt = TextEditingController();
  var passwordTxt = TextEditingController();
  var formKey = GlobalKey<FormState>();

  void registerValidation(authController) {
      authController.Register(nameTxt.text, emailTxt.text, passwordTxt.text);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    AuthViewModel authController = Get.put(AuthViewModel());

    return Scaffold(
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: SizedBox(
            height: size.height,
            child: Stack(
              children: [
                Container(
                  width: size.width,
                  height: size.height,
                  child: Image.asset(
                    'assets/images/background-reg.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Center(
                    child: Column(
                      children: [
                        Expanded(
                          child: const SizedBox(),
                        ),
                        Expanded(
                          flex: 10,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(
                                  sigmaY: 25,
                                  sigmaX: 25,
                                  tileMode: TileMode.clamp),
                              child: SizedBox(
                                width: w100(context, 90), // 90%
                                child: Form(
                                  key: formKey,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h100S(context, 3),
                                        ),
                                        child: Text('New Account',
                                          style: TextStyle(
                                            fontSize: h100S(context, 4),
                                            fontWeight: FontWeight.w600,
                                            color: colorText2.withOpacity(.8),
                                          ),
                                        ),
                                      ),
                                      DefaultTextField(
                                        width: w100(context, 85),
                                        fontSize: h100S(context, 2.5),
                                        controller: nameTxt,
                                        prefixIcon:
                                            Icons.account_circle_outlined,
                                        hintText: 'Name...',
                                      ),
                                      DefaultTextField(
                                        width: w100(context, 85),
                                        fontSize: h100S(context, 2.5),
                                        controller: emailTxt,
                                        prefixIcon: Icons.email_outlined,
                                        hintText: 'username...',
                                        isEmail: true,
                                      ),
                                      DefaultTextField(
                                        width: w100(context, 85),
                                        fontSize: h100S(context, 2.5),
                                        controller: passwordTxt,
                                        prefixIcon: Icons.lock_outline,
                                        hintText: 'Password...',
                                        isPassword: true,
                                        onSubmit: (String text) {
                                          registerValidation(authController);
                                        },
                                      ),
                                      Obx(
                                        () => !authController.isLoading.value
                                            ? InkWell(
                                                onTap: () {
                                                  registerValidation(authController);
                                                },
                                                child: Container(
                                                  height: h100S(context, 8),
                                                  width: w100(context, 85),
                                                  alignment: Alignment.center,
                                                  decoration: BoxDecoration(
                                                    color: Colors.red
                                                        .withOpacity(.5),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            20),
                                                  ),
                                                  child: Text('REGISTER',
                                                    style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize:
                                                          h100S(context, 3),
                                                      fontWeight:
                                                          FontWeight.w600,
                                                    ),
                                                  ),
                                                ),
                                              )
                                            : const SizedMedia(),
                                      ),
                                      Obx(
                                        () => authController.isLoading.value
                                            ? CircularProgressIndicator(
                                                backgroundColor: colorDanger,
                                              )
                                            : const SizedMedia(),
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          defaultTextButton(
                                              text: 'sign in',
                                              function: () => Get.back(),
                                              background: Colors.transparent,
                                              fontSize: h100S(context, 2)),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Expanded(
                          child: SizedBox(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
