import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:get/get.dart';
import 'package:task_app/get_x/auth_controller.dart';
import 'package:task_app/modules/auth/register_screen.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';
import 'package:task_app/tools/component/strings.dart';

class LoginScreen extends StatelessWidget {

  var textEmail = TextEditingController();
  var textPassword = TextEditingController();

  var formKey = GlobalKey<FormState>();

  void loginValidation(authController) {
    if (formKey.currentState.validate()) {
      if(textEmail.text.length == 0){
        toasts(msg: "username must not be empty",background: colorDanger); return;
      }
      if(textPassword.text.length < 6){
        toasts(msg: "Password must least 6 latters",background: colorDanger); return;
      }

      authController.login(textEmail.text, textPassword.text);
    }
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    AuthViewModel authController = Get.put(AuthViewModel());

    return Scaffold(
      body: ScrollConfiguration(
        behavior: MyBehavior(),
        child: SingleChildScrollView(
          child: SizedBox(
            height: size.height,
            child: Stack(
              children: [
                Container(
                  width: size.width,
                  height: size.height,
                  child: Image.asset(
                    'assets/images/background-login.jpg',
                    fit: BoxFit.cover,
                  ),
                ),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Center(
                    child: Column(
                      children: [
                        const Expanded(
                          child: const SizedBox(),
                        ),
                        Expanded(
                          flex: 8,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(30),
                            child: BackdropFilter(
                              filter: ImageFilter.blur(sigmaY: 25, sigmaX: 25),
                              child: SizedBox(
                                width: size.width * .9,
                                child: Form(
                                  key: formKey,
                                  child: Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(
                                          top: h100S(context, 2),
                                        ),
                                        child: Text('sign in',
                                          style: TextStyle(
                                            fontSize: 25,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white.withOpacity(.8),
                                          ),
                                        ),
                                      ),
                                      SizedMedia(
                                        h: h100S(context, 4),
                                      ),
                                      DefaultTextField(
                                        width: w100(context, 85),
                                        controller: textEmail,
                                        prefixIcon: Icons.email_outlined,
                                        hintText: 'username...',
                                        isEmail: true,
                                      ),
                                      DefaultTextField(
                                        width: w100(context, 85),
                                        controller: textPassword,
                                        prefixIcon: Icons.lock_outline,
                                        hintText: 'Password...',
                                        isPassword: true,
                                        onSubmit: (String text) {
                                          loginValidation(authController);
                                        },
                                      ),
                                      const SizedMedia(
                                        h: 3,
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Expanded(
                                            child: DefaultTextButton(
                                              onPressed: () => toasts(
                                                  msg:
                                                      'Forgotten password! button pressed'),
                                              label: 'Forget Password',
                                              background: Colors.transparent,
                                            ),
                                          ),
                                          Expanded(
                                            child: DefaultTextButton(
                                              onPressed: () => Get.to(RegisterScreen()),
                                              label: 'New Account',
                                              background: Colors.transparent,
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedMedia(
                                        h: 3,
                                      ),

                                      Obx(()=> !authController.isLoading.value ?
                                      InkWell(
                                        onTap: () {
                                          loginValidation(authController);
                                        },
                                        child: Container(
                                          margin: EdgeInsets.only(
                                            bottom: size.height * PI * 0.7,
                                          ),
                                          height: size.height * PI * 10,
                                          width: size.width / 1.25,
                                          alignment: Alignment.center,
                                          decoration: BoxDecoration(
                                            color:
                                            Colors.green.withOpacity(.5),
                                            borderRadius:
                                            BorderRadius.circular(20),
                                          ),
                                          child: Text('login',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: size.height * PI * 4,
                                              fontWeight: FontWeight.w600,
                                            ),
                                          ),
                                        ),
                                      ) : const SizedMedia(),
                                      ),


                                      Obx(()=> authController.isLoading.value ?
                                          CircularProgressIndicator(
                                          backgroundColor: colorSuccess,
                                        ): const SizedMedia(),
                                      ),

                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        const Expanded(
                          child: const SizedBox(),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
