import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:fluttertoast2/fluttertoast.dart';
import 'constants.dart';


// // msg toast
Future<bool> toasts({
  @required String msg,
  bool long = true,
  bool center = false,
  Color background = colorSuccess,
  Color color = colorText4,
  double size = 16.0,
}) =>
    Fluttertoast.showToast(
        msg: msg,
        toastDuration:
        long ? ToastDuration.LENGTH_LONG : ToastDuration.LENGTH_SHORT,
        toastGravity: center ? ToastGravity.CENTER : ToastGravity.BOTTOM,
        durationTime: 1,
        backgroundColor: background,
        textColor: color,
        fontSize: size);



// Decoration radius and Shadow
class WidgetRadiusAndShadow extends StatelessWidget{

  final double raduis,spreadRadius,blurRadius,offsetX,offsetY;
  final Widget child;
  final Color color;
  const WidgetRadiusAndShadow(
       {@required this.child,
        this.raduis = 10,
        this.spreadRadius = 4,
        this.blurRadius = 3,
        this.offsetX = 2,
        this.offsetY = 2,
        this.color ,
        Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(raduis),
          boxShadow: [
            BoxShadow(
              spreadRadius: spreadRadius,
              color: color ?? Colors.black.withOpacity(0.4),
              offset: Offset(offsetX,offsetY),
              blurRadius: blurRadius,
            )
          ],
        ),
        child: child,
    );
  }
}



// return width %
double w100(BuildContext context,width) {
  return MediaQuery.of(context).size.width * 0.01 * width;
}

// return height % ( Scaffold , Appbar , BottomNavigationBar )
double h100(BuildContext context,height) {
  return (MediaQuery.of(context).size.height -
      Scaffold.of(context).appBarMaxHeight -
      MediaQuery.of(context).padding.top -
      MediaQuery.of(context).padding.bottom -
      kBottomNavigationBarHeight
  ) * 0.01 * height;
}

// return height % ( Scaffold without BottomNavigation )
double h100S(BuildContext context,height) {
  return (MediaQuery.of(context).size.height -
      MediaQuery.of(context).padding.top -
      MediaQuery.of(context).padding.bottom
  ) * 0.01 * height;
}


// SizedBox with Media Query
class SizedMedia extends StatelessWidget{
  final double w,h;
  const SizedMedia({Key key, this.w = 0, this.h = 0}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: w,
      height: h,
    );
  }
}


// Behavior for ScrollConfiguration (scroll content)
class MyBehavior extends ScrollBehavior {
  @override
  Widget buildViewportChrome(
      BuildContext context,
      Widget child,
      AxisDirection axisDirection,
      ) {
    return child;
  }
}


// Text Widget
class DefaultText extends StatelessWidget {

 final String value;
 final int maxLines;
 final TextOverflow overflow;
 final TextAlign align ;
 final double size;
 final Color color;
 final String font;
 final FontWeight weight;
 final bool italic;
 final bool lineThrough;
 final double spacing;

  const DefaultText(this.value,{this.maxLines = 1, this.overflow = TextOverflow.clip, this.align = TextAlign.start,
    this.size, this.color, this.font,
    this.weight = FontWeight.normal, this.italic = false, this.lineThrough = false, this.spacing = 1.0,
    Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(value,
      maxLines: maxLines,
      overflow: overflow,
      textAlign: align,
      style: TextStyle(
        fontSize: size,
        fontFamily: font,
        fontWeight: weight,
        fontStyle: italic ? FontStyle.italic : FontStyle.normal,
        color: color,
        letterSpacing: spacing,
        decoration:
        lineThrough ? TextDecoration.lineThrough : TextDecoration.none,
      ),
    );
  }
}

// default Text Form Field component
class DefaultTextField extends StatelessWidget{
  final double width,height,padding,borderRadius,fontSize,fontSizeHint,iconSize;
  final int maxLines;
  final String hintText;
  final Alignment alignment;
  final Color color,colorHint,background;
  final IconData prefixIcon;
  final bool isPassword,isEmail,isNumber;
  final TextEditingController controller;
  final Function onChange , onValidate , onTap , onSubmit;

  const DefaultTextField({Key key,
    this.controller,
    this.width ,
    this.height,
    this.fontSize,
    this.padding = 8,
    this.alignment = Alignment.center,
    this.background,
    this.borderRadius = 20,
    this.color,
    this.maxLines = 1,
    this.isPassword = false,
    this.isEmail = false,
    this.isNumber = false,
    this.prefixIcon,
    this.iconSize,
    this.hintText,
    this.colorHint,
    this.fontSizeHint = 16,
    this.onChange,
    this.onValidate,
    this.onTap,
    this.onSubmit
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height ,
      // margin: EdgeInsets.symmetric(vertical: size.width / margin),
      alignment: alignment,
      padding: EdgeInsets.only(right: padding),
      decoration: BoxDecoration(
        color: background ?? colorText1.withOpacity(.1),
        borderRadius: BorderRadius.circular(borderRadius),
      ),
      child: TextFormField(
        controller: controller,
        style: TextStyle(
          color: color ?? colorText4.withOpacity(.9),
          fontSize: fontSize,
        ),
        obscureText: isPassword,
        maxLines: maxLines,
        keyboardType: isEmail ? TextInputType.emailAddress : (isNumber ? TextInputType.number : TextInputType.text),
        decoration: InputDecoration(
          prefixIcon: prefixIcon != null ? Icon(
            prefixIcon,
            color: color ?? colorText4.withOpacity(.8),
            size: iconSize ?? 18 ,
          ) : null,
          border: InputBorder.none,
          hintMaxLines: 1,
          hintText: hintText??'',
          hintStyle: TextStyle(
            fontSize: fontSizeHint,
            color: colorHint ?? colorText4.withOpacity(.5),
          ),
        ),
        onChanged: onChange,
        validator: onValidate,
        onTap: onTap,
        onFieldSubmitted: onSubmit,
      ),
    );
  }
}


class DefaultTextButton extends StatelessWidget{

  final double width,height,fontSize,radius,iconSize;
  final Color background,color,iconColor;
  final bool isBold,isUpperCase;
  final TextAlign textAlign;
  final IconData icon;
  final MainAxisAlignment mainAxisAlignment;
  final Function onPressed;
  final String label;

  const DefaultTextButton({@required this.onPressed, @required this.label,this.width, this.height = 45, this.fontSize, this.radius, this.iconSize, this.background, this.color, this.iconColor, this.isBold = false, this.isUpperCase = true, this.textAlign, this.icon, this.mainAxisAlignment, Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius ?? 0),
        color: background ?? colorPrimary,
      ),
      child: MaterialButton(
          onPressed: onPressed,
          child: Row(
            mainAxisAlignment: mainAxisAlignment ?? MainAxisAlignment.center,
            children: [
              Text(
                (isUpperCase ? label.toUpperCase() : label) + ( icon!=null ? '    ' : '' ),
                style: TextStyle(
                  color: color ?? colorText4,
                  fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
                  fontSize: fontSize ?? 16,
                ),
                textAlign: textAlign ?? TextAlign.center,
              ),
              if (icon != null)
                Icon(
                  icon,
                  color: iconColor ?? colorText4,
                  size: iconSize ?? 16,
                ),
            ],
          )),
    );
  }

}


Container defaultTextButton({
  double width,
  double height = 40.0,
  double fontSize = 20.0,
  Color background = colorPrimary,
  Color color = colorText4,
  bool isBold = false,
  bool isUpperCase = true,
  TextAlign textAlign = TextAlign.center,
  double radius = 0.0,
  IconData icon,
  Color iconColor,
  double iconSize,
  @required Function function,
  @required String text,
}) =>
    Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        color: background,
      ),
      child: MaterialButton(
          onPressed: function,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Text(
                isUpperCase ? text.toUpperCase() : text,
                style: TextStyle(
                  color: color,
                  fontWeight: isBold ? FontWeight.bold : FontWeight.normal,
                  fontSize: fontSize,
                ),
                textAlign: textAlign,
              ),
              if (icon != null)
                Icon(
                  icon,
                  color: iconColor,
                  size: iconSize,
                ),
            ],
          )),
    );


