import 'dart:ui';
import 'package:flutter/material.dart';

bool isDarkTheme = false;
String lang = 'en';

String token;
const String userImageDefault = 'assets/images/userImage.jpg';

ThemeData defaultTheme(BuildContext context) =>ThemeData(
    primaryColorDark: colorText4,
    primarySwatch: colorPrimary,
    primaryColor: colorPrimary,
    primaryTextTheme: TextTheme(
        bodyText1: TextStyle(color: isDarkTheme ? colorText4 : colorText1),
        bodyText2: TextStyle(color: isDarkTheme ? colorText3 : colorText2),
        subtitle1: TextStyle(color: isDarkTheme ? colorText4 : colorText1),
        subtitle2: TextStyle(color: isDarkTheme ? colorText3 : colorText2),
        caption: TextStyle(color: colorText1)
    ),

    fontFamily: 'cairo',
    brightness: isDarkTheme ? Brightness.dark : Brightness.light,

    appBarTheme: AppBarTheme(
      backgroundColor: isDarkTheme ? colorText2 : colorPrimary,
      titleTextStyle: TextStyle(color: Theme.of(context).textTheme.bodyText1.color),
      textTheme: TextTheme(title: TextStyle(
          color: isDarkTheme ? colorText4 : colorText1,
          fontFamily: 'cairo',
          fontSize: Theme.of(context).textTheme.title.fontSize,
          fontWeight: FontWeight.bold
        ),
      ),
      iconTheme: IconThemeData(

      ),
      // titleTextStyle:TextStyle(color: isDarkTheme? colorText4 : colorText1,) ,
    ),

    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      selectedItemColor: colorPrimary,
      elevation: 10,
      backgroundColor: isDarkTheme ? colorText1 : colorText4,
    ),

    tabBarTheme: TabBarTheme(
      labelColor: isDarkTheme ? colorText4: Theme.of(context).primaryColor,
      unselectedLabelColor: isDarkTheme ? colorText3: colorText2,
    ),

);

const Color colorText1 = Colors.black;
const Color colorText2 = Colors.black45;
const Color colorText3 = Colors.grey;
const Color colorText4 = Colors.white;

const Color colorPrimary = Colors.blue;
const Color colorSecondary = Colors.orange;
const Color colorWarning = Colors.yellow;
const Color colorSuccess = Colors.green;
const Color colorDanger = Colors.redAccent;

// to use random color
const List<Color> rndColor =[
  Colors.grey,
  Colors.blue,
  Colors.orange,
  Colors.brown,
  Colors.green,
  Colors.indigo,
];

// types of users
List typesUser=[
"Normal",
"Silver",
"Gold",
];

// types of users
const List<Color> typesUserColor=[
Colors.black54,
Colors.black12,
Colors.yellow,
];