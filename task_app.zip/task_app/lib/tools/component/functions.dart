import 'package:intl/intl.dart';

  class CustomFunctions {

     static String readTimestamp(int timestamp) {
        var now = DateTime.now();
        var format = DateFormat('h:mm a','ar_IQ');
        var date = DateTime.fromMillisecondsSinceEpoch(timestamp);
        var diff = now.difference(date);
        var time = '';

        if (diff.inSeconds <= 0 || diff.inSeconds > 0 && diff.inMinutes == 0 || diff.inMinutes > 0 && diff.inHours == 0 || diff.inHours > 0 && diff.inDays == 0) {
          time = format.format(date);
        } else if (diff.inDays > 0 && diff.inDays < 7) {
            if (diff.inDays == 1)
              time = diff.inDays.toString() + ' ي';
            else
              time = diff.inDays.toString() + ' ي';
        } else {
            if (diff.inDays == 7)
              time = (diff.inDays / 7).floor().toString() + ' أ';
            else
              time = (diff.inDays / 7).floor().toString() + ' أ';
        }
        return time;
     }
  }