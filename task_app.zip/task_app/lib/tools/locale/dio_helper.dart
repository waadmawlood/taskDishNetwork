import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:task_app/tools/component/strings.dart';

class DioHelper
{
  static Dio dio;  // use hole App

  static void init()  // like constructor to define dio variable
  {
    dio = Dio(
      BaseOptions(
        baseUrl: URL,
        receiveDataWhenStatusError: true,
        responseType: ResponseType.json,
        receiveTimeout: 5000,
        connectTimeout: 5000,
        headers: {
          HttpHeaders.contentTypeHeader: 'application/json',
          'accept' : 'application/json',
          'Content-Type' : 'application/json',
        }
      )
    );
  }

  // api get methods
  static Future<Response> getData({
    @required String url,
    Map<String,dynamic> query,
    String lang = 'en',
    String token,
  }) async
  {
    return await dio.get(url,
        queryParameters: query,
        options: Options(headers: {
          'Content-Language' : lang,
          if(token != null)'Authorization' : 'Bearer ' + token,
        })
    );
  }

  // api post methods
  static Future<dynamic> postData(
      {
        @required String url,
        @required Map<String, dynamic> data,
        String lang = 'en',
        String token,
        String contentType = 'application/json',   //multipart/form-data
      }) async
  {
    return await dio.post(
      url,
      data: data,
      options: Options(
        headers: {
          'Content-Type' : contentType,
          'Content-Language' : lang,
          if(token != null)'Authorization' : 'Bearer ' + token,
        },
      ),
    );
  }

}