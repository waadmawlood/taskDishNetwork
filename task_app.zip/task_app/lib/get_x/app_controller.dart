

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'file:///D:/Mobile_App/task_app/lib/get_x/api_functions.dart';
import 'package:task_app/models/post_model.dart';
import 'package:task_app/models/user_model.dart';
import 'package:task_app/modules/auth/login_screen.dart';
import 'package:task_app/modules/bottoms/home_screen.dart';
import 'package:task_app/modules/bottoms/setting_screen.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';
import 'package:task_app/tools/locale/cache_helper.dart';
import 'package:task_app/tools/locale/dio_helper.dart';

class AppViewModel extends GetxController{

  var currentTabIndex = 0.obs;   // index of Bottom Navigator
  var auth = UserModel().obs;    // Model to save my auth
  var posts = <PostModel>[].obs;  // list of users model
  var fileImage = File('').obs;   // file to change image user
  var isLoading = false.obs;     // flag

  // BottomNavigationBar
  List pages = [
    HomeScreen(),
    SettingScreen()
  ];

  // change index of BottomNavigationBar
  void changeTabIndex(int value){
    currentTabIndex.value = value;
  }

  // get my inforamtion from GET URL api/user
  Future<void> getAuth(String token) async{
    if(token != null && token != ''){
      var response = await DioHelper.getData(url: 'user',token: token);
      if(statusCodeResponse(response)){
        if(isSuccessData(response)){
          auth.value = UserModel.fromJson(response.data);
        }
      }else{
        toasts(msg: "There is a Error",background: colorDanger);
      }
    }
  }

  // get all products
  Future<void> getFirstPosts(String token)async{
    posts.value = <PostModel>[].obs;
    var response = await DioHelper.getData(url: 'products',token: token);
    if(statusCodeResponse(response)){
      if(isSuccessData(response)){
        List<dynamic> map= response.data['data'];
        map.forEach((value){
          posts.value.add(PostModel.fromJson(value));
        });
      }
    }
  }


  // logout
  Future<void> logout() async{
    await DioHelper.postData(url: 'logout',token: token, data: {}).then((value){
      toasts(msg: value.data['msg']);
    });
    CacheHelper.removeData(key: 'token');
    auth = new UserModel().obs;
    Get.off(LoginScreen());
  }


  // image Picker Package and function to get File image
  var picker = ImagePicker();
  Future<void> getImageFile({
    bool isCamera = false,
  }) async
  {
    final pickedFile = await picker.getImage(source: isCamera? ImageSource.camera : ImageSource.gallery,
      imageQuality: 60,
    );
    if(pickedFile !=null) {
        fileImage.value = File(pickedFile.path);
    }
  }

  // empty image return null
  void emptyImage()
  {
    fileImage.value = null;
  }

  //update user
  Future<void> updateUser(String name,String username,String password,) async {
    if(name.length < 4) { toasts(msg: "name at least 4",background: colorDanger); return; }
    if(username.length < 3) { toasts(msg: "username at least 4",background: colorDanger); return; }
    if(password.length < 6) { toasts(msg: "password at least 6",background: colorDanger); return; }
    isLoading.value = true;


    if (fileImage.value == null) return;

    Map<String,dynamic> info = {
      'name': name,
      'username': username,
      'password':password,
      "image" : fileImage.value??'user_default.jpg'
    };
    var response = await DioHelper.postData(url: 'user',token: token,data: info);
    if(statusCodeResponse(response)){
      if(isSuccessData(response)){
        await getAuth(token);
        isLoading.value = false;
        Get.back();
      }
    }
    isLoading.value = false;
  }

 @override
  Future<void> onInit() async {
    // TODO: implement onInit
    super.onInit();
    await getAuth(token);
    await getFirstPosts(token);
    fileImage.value = null;
  }


  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }
}