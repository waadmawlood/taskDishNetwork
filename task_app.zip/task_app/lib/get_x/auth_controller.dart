
import 'package:get/get.dart';
import 'file:///D:/Mobile_App/task_app/lib/get_x/api_functions.dart';
import 'package:task_app/layout/app_layout.dart';
import 'package:task_app/tools/component/components.dart';
import 'package:task_app/tools/component/constants.dart';
import 'package:task_app/tools/locale/cache_helper.dart';
import 'package:task_app/tools/locale/dio_helper.dart';

class AuthViewModel extends GetxController{

  var isLoading = false.obs;

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }

  Future<void> login(String username,String password) async{
    isLoading.value =true;
    Map<String,dynamic> credent = {'username': username,'password':password};
    var dio = await DioHelper.postData(url: 'login', data: credent);
    if(statusCodeResponse(dio)){
      if(isSuccessData(dio)){
        // debugPrint(dio.data['data']['token']);
        token = dio.data['data']['token'];
        CacheHelper.saveData(key: 'token', value: token);
        toasts(msg: dio.data['msg']);
        isLoading.value =false;
        Get.offAll(AppLayout());
      }
      else{
        isLoading.value =false;
        toasts(msg: dio.data['msg'],background: colorDanger);
      }
    }
    else{
      isLoading.value =false;
      toasts(msg: "There is a Error",background: colorDanger);
    }
    isLoading.value =false;
  }




  Future<void> Register(String name,String username,String password) async{
    isLoading.value =true;
    Map<String,dynamic> credent = {
      'name': name,
      'username': username,
      'password':password
    };
    var dio = await DioHelper.postData(url: 'register', data: credent);
    if(statusCodeResponse(dio)){
      if(isSuccessData(dio)){
        token = dio.data['data']['token'];
        CacheHelper.saveData(key: 'token', value: token);
        toasts(msg: dio.data['msg']);
        isLoading.value =false;
        Get.offAll(AppLayout());
        update();
      }
      else{
        isLoading.value =false;
        String errors = errorMsg(dio.data['data']);
        toasts(msg: errors,background: colorDanger);
      }
    }
    else{
      isLoading.value =false;
      toasts(msg: "There is a Error",background: colorDanger);
    }
    isLoading.value =false;
  }


}