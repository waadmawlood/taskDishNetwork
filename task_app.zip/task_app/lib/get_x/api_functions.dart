
/*
   success response
   $response=[
      'success'=> true,
      'status' => $status,  // code : 200 , 404 , 403 .....
      'msg'    => $message,
      'data'   => $result,
   ];
*/

/*
   false response
   $response=[
       'success'=>false,
       'msg'    =>$errorMsg,
       'status' => $status,  // code : 200 , 404 , 403 .....
       'data'   =>'',
   ];
*/


import 'package:dio/dio.dart';

bool statusCodeResponse(Response response){
 return response.statusCode == 200 ? true : false;
}

int statusCodeData(Response response){
  return response.data['status'];
}

bool isSuccess(Response response){
  return response.data['success'] ? true : false;
}

bool isSuccessData(Response response){
  return response.data['success'] && response.data['status'] == 200 ? true : false;
}

String errorMsg(err){
  var errorMap = Map<String, List<dynamic>>.from(err);
  String temp = '';
  errorMap.forEach((key, List<dynamic> value) {
    temp += key.toString() + " : ";
    value.forEach((element) {
      temp += element.toString() + ", ";
    });
    temp +="\n";
  });
  temp = temp == ''? '' : temp.substring(0,temp.length - 2);
  return temp;
}

