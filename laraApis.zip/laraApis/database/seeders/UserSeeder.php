<?php

namespace Database\Seeders;

use App\Models\Role;
use App\Models\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $user = User::create([
            'name' => 'admin Company',
            'username' => 'dish',
            'password' => bcrypt(123456)
        ]);

        $role_id = Role::where('name','admin')->firstOrfail()->id ?? 2;
        $user->roles()->attach($role_id);
    }
}
