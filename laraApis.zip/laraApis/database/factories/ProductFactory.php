<?php

namespace Database\Factories;

use App\Models\Product;
use App\Models\Type;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

class ProductFactory extends Factory
{

    protected $model = Product::class;
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        $types = Type::select('id')->get()->pluck('id');
        $temp = array();
        foreach($types as $type){
            $temp[$type] = rand(20,90);
        }

        return [
            'name' => $this->faker->name(),
            'price' => $temp,
        ];

    }
}
