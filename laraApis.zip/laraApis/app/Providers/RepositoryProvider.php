<?php

namespace App\Providers;

use App\Repository\ProductRepositoryInterface;
use Illuminate\Support\ServiceProvider;
use App\Repository\Eloquent\ProductRepository;
use App\Repository\Eloquent\UserRepository;
use App\Repository\UserRepositoryInterface;

class RepositoryProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(ProductRepositoryInterface::class, ProductRepository::class);
        $this->app->bind(UserRepositoryInterface::class, UserRepository::class);
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
