<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'username',
        'password',
        'image',
        'type_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = ['password','remember_token'];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [];


    // accessor function return url full of image
    public function getImageAttribute(){
        return asset('storage/images/users').'/'. $this->attributes["image"];
    }

    // RelationShip to type model to user
    public function types(){
        return $this->hasMany(Type::class,'type_id','id');
    }


    // RelationShip to role model to user
    public function roles(){
        return $this->belongsToMany(Role::class)->orderByPivot('role_id','desc');
    }

    // function to bring role [checked]
    public function hasRole($role){
        if($this->roles()->where('name',$role)->first()){
            return true;
        }
        return false;
    }

    // RelationShip has role or no  to user  [array or single]
    public function hasAnyRole($roles){
        if(is_array($roles)) {
            foreach ($roles as $role){
                if($this->hasRole($role)){
                    return true;
                }
            }
        }else{
            if($this->hasRole($roles)){
                return true;
            }
        }
        return false;
    }

}
