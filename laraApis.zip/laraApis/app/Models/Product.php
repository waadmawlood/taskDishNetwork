<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Product extends Model
{
    use HasFactory , HasTranslations;
    protected $fillable = ['name','image','price','active'];

    // to use multi values by json
    public $translatable = ['price'];

    // to add new attribute when json Api from any function in model
    protected $appends = [];

    // prevent insert , update => columns name
    protected $guarded = [];


    // scop function to return price by type [normal,silver,gold] json
    public function scopeSelectJson($query,$type)
    {
        return $query->select(
            "id",
            "name",
            "image",
            "price->$type as Price",
            "active",
            "created_at",
            "updated_at");
    }

    // accessor function return url full of image
    public function getImageAttribute(){
        return asset('storage/images/products').'/'. $this->attributes["image"];
    }

}
