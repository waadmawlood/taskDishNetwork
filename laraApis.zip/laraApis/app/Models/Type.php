<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Type extends Model
{
    use HasFactory;
    protected $fillable = ['name'];
    public $timestamps = false;

    // RelationShip to user model to type
    public function users(){
        return $this->belongsTo(User::class,'id','type_id');
    }

}
