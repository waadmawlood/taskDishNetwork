<?php

namespace App\Http\Controllers\api;
use App\Http\Controllers\api\BaseController;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;


class PassportAuthController extends BaseController
{




/**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('auth:api', ['except' => ['login','register']]);
    }


    /**
     * Registration
     */
    public function register(Request $request)
    {
        $msg = [
            'name.min' => 'name at least 4',
            'username.min' => 'username at least 3',
            'password.min' => 'password at least 6',
        ];
        $validator = Validator::make($request->all(),[
            'name' => 'required|min:4',
            'username' => 'required|min:3',
            'password' => 'required|min:6',
        ],$msg);

        if ($validator->fails()) {
            return $this->apiError(trans('auth.failed_reg'),$validator->errors() ,422);
        }

        try{
            $user = User::create([
                'name' => $request->name,
                'username' => $request->username,
                'password' => bcrypt($request->password)
            ]);

            $token = $user->createToken('LaravelAuthApp')->accessToken;
            return $this->apiResponse(['token' => $token],trans('auth.success'));
        } catch(\Exception $e){
            return $this->apiError(trans('auth.failed_reg'),$validator->errors(),422);
        }
    }

    /**
     * Login
     */
    public function login(Request $request)
    {
        $data = [
            'username' => $request->username,
            'password' => $request->password
        ];

        if (auth()->attempt($data)) {
            $token = auth()->user()->createToken('LaravelAuthApp')->accessToken;
                return $this->apiResponse(['token' => $token],trans('auth.success'), 200);
        } else {
            return $this->apiError(trans('auth.failed'),[], 403);
        }
    }

    // logout
    public function logout(Request $request) {
        $accessToken = auth()->user()->token();
        $token= $request->user()->tokens->find($accessToken);
        $token->revoke();
        return $this->apiResponse(null,'You have been successfully logged out.');
    }


    // return get access token
    public function token() {
        $tokenUser = auth()->user()->token();
        return $this->apiResponse(["access_token" => $tokenUser],"");
    }


    // get my information user auth
    public function userProfile() {
        $user = User::with('roles')->find(auth()->user()->id);
        return $this->apiResponse($user,"my Account");
    }
}
