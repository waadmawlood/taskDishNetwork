<?php

namespace App\Http\Controllers\api;
use App\Http\Controllers\api\BaseController;
use App\Models\Type;
use App\Models\User;
use App\Repository\UserRepositoryInterface;
use Illuminate\Http\Request;


class UserController extends BaseController
{
    private $repo;

    public function __construct(UserRepositoryInterface $usertModel)
    {
        $this->repo = $usertModel;
    }

    // get all user with roles
    public function index(){
        return $this->repo->getAll();
    }

    // get only admins
    public function getAdmins(){
        return $this->repo->getAdmins();
    }


    // get user id
    public function find($id){
        return $this->repo->find($id);
    }


    // add user to admin
    public function addAdmin($id){
        return $this->repo->addAdmin($id);
    }

    // remove user from admin
    public function deleteAdmin($id){
        return $this->repo->deleteAdmin($id);
    }

    //change type user
    public function changeType(Request $request,$id){
        return $this->repo->changeTypeUser($request,$id);
    }

    //get all type
    public function getTypes(){
        return Type::all(); // get last 3 type id
    }

    // get my information user auth
    public function userUpdate(Request $request) {
        $user =  User::find(auth()->user()->id);
        $img = $this->repo->uploadImageUsers($request->image);
        if($img != 'user_default.jpg')
            $dleImage = $this->repo->deleteImageUsers($user->image); // delete image users
            $user->update([
            "name" => $request->name,
            "username" => $request->username,
            "password" => bcrypt($request->password),
            "image" => $img,
        ]);
        return $this->apiResponse($user,"my Account Updated");
    }
}
