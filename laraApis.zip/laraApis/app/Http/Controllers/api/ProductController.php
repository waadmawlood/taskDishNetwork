<?php

namespace App\Http\Controllers\api;
use App\Http\Controllers\api\BaseController;
use App\Http\Requests\StoreProductRequest;
use App\Models\Product;
use App\Models\Type;
use App\Repository\ProductRepositoryInterface;


class ProductController extends BaseController
{
    private $repo;
    private Type $typeModel;

    public function __construct(ProductRepositoryInterface $productModel)
    {
        $this->repo = $productModel;
        $this->typeModel = new Type();
    }


    // get all products ORder DESC from url GET : api/products
    public function index()
    {
        $posts = $this->repo->getAll();
        if($posts)
            return $this->apiResponse($posts,"All Porducts");
        else
            return $this->apiError("Error No Porducts In Data",null);
    }

    // get paginate products from url GET : api/products/pages
    public function getPages()
    {
        //$posts = $this->repo->getPagination();
        $posts = Product::paginate(8);
        if($posts)
            return $this->apiResponse($posts,"All Porducts");
    }

    // create product from url POST : api/products
    public function store(StoreProductRequest $request)
    {
        $types = $this->repo->getPluck($this->typeModel); // get last 3 type id

        $img = $this->repo->uploadImageProduct($request->image); // upload image

        $post = Product::create([
            "name"=> $request->name,
            "price"=> [$types[0]=>$request->gold, $types[1]=>$request->silver, $types[2]=>$request->normal],
            "active"=> $request->active ?? true,
            "image"=> basename($img),
        ]);

        if($post)
            return $this->apiResponse($post,"Done create product id : $post->id");
        else
            return $this->apiError("Error when store Data",null);
    }


    // get information of one product from url GET : api/products/{id} use user to return one price type
    public function show($id)
    {
            //$lang = app()->getLocale(); // if i use Localization
            $post = $this->repo->find($id);

            if($post)
                return $this->apiResponse($post,"get this product");
            else
                return $this->apiError("Error No Porduct In Data",null);
    }


    // get information of one product from url GET : api/products/{id} use admin to return all price type
    public function showAdmin($id)
    {
            //$lang = app()->getLocale(); // if i use Localization
            $post = Product::find($id);

            if($post)
                return $this->apiResponse($post,"get this product");
            else
                return $this->apiError("Error No Porduct In Data",null);
        }


    // update product from url POST : api/products/{id}
    public function update(StoreProductRequest $request, $id)
    {
        $post = Product::find($id);
        if(!$post)
            return $this->apiError("Error No Porduct Find In Data",null);

        $img = $this->repo->uploadImageProduct($request->image); // upload image
        if($img != 'product123.jpg')
            $dleImage = $this->repo->deleteImageProduct($post->image); // delete image

        // get last 3 type id
        $types = $this->repo->getPluck($this->typeModel);

        $post->name= $request->name;
        $post->price= [$types[0]=>$request->gold, $types[1]=>$request->silver, $types[2]=>$request->normal];
        $post->active= $request->active ?? true;
        $post->image= basename($img);
        $post->save();

        return $this->apiResponse($post,"Done Update product id : $id");
    }

    // delete product from url POST : api/products/destroy/{id}
    public function destroy($id)
    {
        $post = Product::find($id);
        if($post){
            $dl = $this->repo->deleteImageProduct($post->image);
            $post->delete();
            return $this->apiResponse(null,"delete product id : $id");
        }
        else
            return $this->apiError("Error when delete Data",null);
    }
}
