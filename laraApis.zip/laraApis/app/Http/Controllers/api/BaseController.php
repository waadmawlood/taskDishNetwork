<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{

    public function apiResponse($result , $message='',$status=200){
        $response=[
            'success'=> true,
            'status' => $status,
            'msg'    => $message,
            'data'   => $result,
        ];
        return response()->json($response);
    }


    public function apiError($errorMsg , $errorData=[],$status=404){
        $response=[
            'success'=>false,
            'msg'    =>$errorMsg,
            'status' => $status,
            'data'   =>'',
        ];
        if(!empty($errorData))
        {
            $response['data']=$errorData;
        }
        return response()->json($response);
    }

}
