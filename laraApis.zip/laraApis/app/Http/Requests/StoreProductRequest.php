<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    // protected function failedValidation(\Illuminate\Contracts\Validation\Validator $validator)
    // {
    //     return response()->json([
    //         "success" => false,
    //         "msg" => 'Error in validation',
    //         "status" => 422,
    //         "data" => $validator->errors(),
    //     ]);
    // }


    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'name' => 'required',
            'gold' => 'required|numeric',
            'silver' => 'required|numeric',
            'normal' => 'required|numeric',
            'image' =>'image|nullable'
        ];
    }

    public function messages(){
        return [
            'name.required' => 'name must not empty',
            'gold.required' => 'price gold must not empty',
            'silver.required' => 'price silver must not empty',
            'normal.required' => 'price normal must not empty',
        ];
    }



}
