<?php
namespace App\Repository;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

interface UserRepositoryInterface{
    public function getAll();  // general get
    public function getAdmins(); // get only admins
    public function find($id);      // find method ? Maybe return null if fail
    public function changeTypeUser(Request $request, $id);  // change type of user [normal,silver,gold]
    public function addAdmin($id);  // add admin role
    public function deleteAdmin($id);  // delete admin role

    public function userUpdate(Request $request);  // update user from api Mobile Post : api/user
    public function uploadImageUsers($file,$target = 'storage/images/users/') : string;
    public function deleteImageUsers($file,$target = 'storage/images/users/') : bool;

}
