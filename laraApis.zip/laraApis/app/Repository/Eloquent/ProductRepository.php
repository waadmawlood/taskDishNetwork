<?php

namespace App\Repository\Eloquent;
use App\Repository\ProductRepositoryInterface;
use Illuminate\Database\Eloquent\Model;
use App\Models\Product;

class ProductRepository implements ProductRepositoryInterface{


    private Product $model;

    public function __construct(Product $model)
    {
        $this->model = $model;
    }


    //get data
    public function getAll()
    {
        return $this->model->selectJson(auth()->user()->type_id ?? 1)  // scope in Model
            ->orderBy('id','desc')
            ->get();
    }

        //get data
    public function getPagination($count = 15)
    {
        return $this->model->paginate($count);
    }

    // create method : post
    public function create(array $attributes)
    {
        return $this->model->create($attributes);
    }

    // find method : get
    public function find($id)
    {
        // scope in Model ScopeSelectJson();
        return $this->model->selectJson(auth()->user()->type_id ?? 1)->find($id);
    }

    // get pluck array of select model
    public function getPluck(Model $mdl, $select = 'id', $limit = 3,$order = 'desc')
    {
        return $mdl->select($select)->orderBy($select,$order)->limit($limit)->get()->pluck($select);
    }

    // uplaod imge and return path
    public function uploadImageProduct($file, $target = 'storage/images/products/'): string
    {
        if($file)
        {
            return  basename($file->store('public/images/products'));
        }
        return 'product123.jpg';
    }

    // delete image product
    public function deleteImageProduct($file, $target = 'storage/images/products/') : bool
    {
        if(file_exists(public_path($target).'/'.$file) && $file != "product123.jpg"){
            unlink(public_path($target).'/'.$file);
            return true;
        }
        return false;
    }

}
