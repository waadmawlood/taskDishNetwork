<?php

namespace App\Repository\Eloquent;

use App\Models\Role;
use App\Models\User;
use App\Repository\UserRepositoryInterface;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class UserRepository implements UserRepositoryInterface{


    private User $model;

    public function __construct(User $model)
    {
        $this->model = $model;
    }


    //get all user
    public function getAll()
    {
        return $this->model->with('roles')->orderBy('id','desc')->get();  // users with roles
    }


    //get all user
    public function getAdmins()
    {
        return $this->model->has('roles')->orderBy('id','desc')->get();  // users with admins roles
    }

    // get user id
    public function find($id){
        return $this->model->find($id);
    }

    // change type of user
    public function changeTypeUser(Request $request,$id){
        return $this->model->find($id)->update(["type_id"=>$request->type_id]);
    }


    // add user to admin
    public function addAdmin($id){
        $user = $this->model->find($id);
        $idAdmin = Role::select('id')->where('name','admin')->limit(1)->get()->pluck('id');
        return $user->roles()->attach($idAdmin);
    }

    // remove user from admin
    public function deleteAdmin($id){
        $user = $this->model->find($id);
        $idAdmin = Role::select('id')->where('name','admin')->limit(1)->get()->pluck('id');
        return $user->roles()->detach($idAdmin);
    }

    // update user from api Mobile
    public function userUpdate(Request $request){

    }

        // uplaod imge and return path
        public function uploadImageUsers($file, $target = 'storage/images/users/'): string
        {
            if($file)
            {
                return basename($file->store('public/images/users'));
            }
            return 'user_default.jpg';
        }

        // delete image product
        public function deleteImageUsers($file, $target = 'storage/images/users/') : bool
        {
            if(file_exists(public_path($target).'/'.$file) && $file != "user_default.jpg"){
                unlink(public_path($target).'/'.$file);
                return true;
            }
            return false;
        }

}
