<?php
namespace App\Repository;
use Illuminate\Database\Eloquent\Model;

interface ProductRepositoryInterface{

    public function getAll();  // general get
    public function getPagination($count = 15);  // general get
    public function create(array $attributes);  // create method  Prodcut Model
    public function find($id);      // find method ? Maybe return null if fail
    public function getPluck(Model $mdl,$select = 'id',$limit = 3);  // to get general any model and pluck to array
    public function uploadImageProduct($file,$target = 'storage/images/products/') : string;
    public function deleteImageProduct($file,$target = 'storage/images/products/') : bool;

}
