<template>
<div class="container">
    <div class="d-flex flex-row flex-warp my-4" style="border-radius: 15px; background-color: lightgrey;">
        <div class="col-md-6 p-4 text-center">
            <img :src="image" alt="img" width="100%">
            <br>
            <h4>{{ porduct.id }} : {{ porduct.name }}</h4>
        </div>
        <div class="col-md-6 p-4">
            <div>
                <form @submit.prevent="submitForm">

                    <div class="input-group mt-3">
                        <span class="input-group-text">Name</span>
                        <input type="text" name="name" class="form-control" placeholder="Name...." v-model="name">
                    </div>

                    <hr>

                    <div class="input-group mt-3">
                        <span class="input-group-text">Normal</span>
                        <input type="text" name="normal" class="form-control" placeholder="normal...." v-model="normal">
                    </div>

                    <div class="input-group mt-3">
                        <span class="input-group-text">Silver</span>
                        <input type="text" name="silver" class="form-control" placeholder="silver...." v-model="silver">
                    </div>

                    <div class="input-group mt-3">
                        <span class="input-group-text">Gold</span>
                        <input type="text" name="gold" class="form-control" placeholder="gold...." v-model="gold">
                    </div>


                    <div class="form-check mt-2">
                        <input class="form-check-input" type="checkbox" name="active" @change="active? active = 1 : active = 0" id="availableCheck" v-model="active">
                        <label class="form-check-label" for="availableCheck">
                            Active
                        </label>
                    </div>

                    <hr>

                    <label for="headerImage" class="form-label"> Add new Image</label>
                    <div class="d-flex flex-row">
                        <div class="flex-grow-1">
                            <input class="form-control form-control-lg" name="image" type="file" placeholder="Add Image" @change="onFileChange">
                        </div>
                    </div>


                    <div class="w-100 text-center mt-4">
                        <button type="submit" class="btn btn-primary w-100"> Edit </button>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>
</template>
<script>
    export default {
        props: ['idRoute','routePre'],
        data(){
            return{
                id : this.idRoute,
                porduct : {},
                types : {},
                name : '',
                gold : '',
                silver : '',
                normal : '',
                active : 1,
                image : '',
                imgUpdate:null
            }
        },
        mounted() {
            axios.get('http://localhost:8080/laraApis/public/api/admin/types')
            .then(response => {
                this.types = response.data;
            });

            axios.get('http://127.0.0.1:8000/api/admin/products/' + this.id)
            .then(response => {
                this.porduct = response.data.data;
                this.name = response.data.data.name;
                this.active = response.data.data.active;
                this.image = response.data.data.image;

                this.gold = response.data.data.price['3'];
                this.silver = response.data.data.price['2'];
                this.normal = response.data.data.price['1'];
            })
            .catch(err => {
                console.error(err);
            });
        },
        methods:{
            //add image file to image
            onFileChange(e) {
                this.imgUpdate = e.target.files[0];
            },


            submitForm(){
                let formData = new FormData();  // new form data
                if(this.name == '' || this.gold == '' || this.silver == '' || this.normal == '')
                {
                    alert('Must not be empty'); return 0;
                }
                formData.append("name", this.name);
                formData.append("gold", this.gold);
                formData.append("silver", this.silver);
                formData.append("normal", this.normal);
                formData.append("active", this.active);
                formData.append("image", this.imgUpdate??'');

                // update From Url POST api/admin/products
                axios.post('http://127.0.0.1:8000/api/admin/products/' + this.id, formData)
                        .then((res) => {
                            window.location.href = this.routePre;
                        })
                        .catch((error) => {
                            alert("There is Error When update Product");
                });
            },
        }
    }
</script>
