<template>
<div class="container-fluid py-5">
    <div class="d-flex flex-row flex-warp">
        <div class="col-md-4 p-3" style="background-color: silver;">
            <h3 class="text-center">Admins</h3>
            <hr>
            <table class="table" width="100%" >
                <thead>
                <tr>
                    <th scope="col">id</th>
                    <th scope="col">name</th>
                    <th scope="col">delete</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="admin in admins" :key="admin.id">
                    <td scope="row">{{ admin.id }}</td>
                    <td>{{ admin.name }}</td>
                    <td>
                        <button @click="deleteAdmin(admin.id)" class="btn btn-danger">Delete</button>
                    </td>
                </tr>
                </tbody>
            </table>

        </div>
        <div class="col-md-8 p-3">
            <h3 class="text-center">Users</h3>
            <hr>

            <table class="table text-dark">
                    <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">name</th>
                        <th scope="col">type</th>
                        <th scope="col">Actions</th>
                    </tr>
                    </thead>
                <tbody>
                    <tr v-for="user in users" :key="user.id" v-if="!user.roles.length">
                        <td scope="row">{{ user.id }}</td>
                        <td>{{ user.name }}</td>
                        <td>
                                <span v-for="type in types" v-if="user.type_id == type.id">
                                    {{ type.name}}
                                </span>
                        </td>
                        <td>
                            <button @click="addAdmin(user.id)" class="btn btn-primary">Admin</button>
                            <button @click="getUserUpdate(user.id)" class="btn btn-warning">Edit</button>
                        </td>
                    </tr>
                </tbody>
            </table>


            <div class="position-fixed top-0 end-0 bottom-0 bg-warning col-md-3" v-if="isEdit == 1">
            <p><button class="btn btn-danger float-end" @click="isEdit = 0">X</button></p>
            <hr>
            <form action="" @submit.prevent="submitForm" class="p-4">

                <br>
                <select name="types" id="" v-model="select"  class="form-select form-control my-5">
                    <option v-for="typ in types" :value="typ.id" @selected="typ.id == typeUpID">{{ typ.name }}</option>
                </select>
                <button type="submit" class="btn btn-success m-auto">Update</button>
            </form>


            </div>



        </div>
    </div>
</div>
</template>
<script>
export default{
    data(){
        return{
            admins : {},
            users : {},
            types : {},
            isEdit : 0,
            select : '',
            idUpdate : '',
            typeUpID : ''
        }
    },
    mounted() {
        axios.get('http://127.0.0.1:8000/api/admin/types')
            .then(response => {
                this.types = response.data;
        });
        this.getAdmins();
        this.getUsers();

    },
    methods:{
        getAdmins(){
            axios.get('http://127.0.0.1:8000/api/admin/admins')
            .then(response => {
                this.admins = response.data;
            });
        },
        getUsers(){
            axios.get('http://127.0.0.1:8000/api/admin/users')
            .then(response => {
                this.users = response.data;
            });
        },

        // add admin by id
        addAdmin(id){
            axios.post('http://127.0.0.1:8000/api/admin/admins/create/' + id)
            .then(response => {
                this.getAdmins();
                this.getUsers();
            });
        },

        // delete admin by id
        deleteAdmin(id){
            axios.post('http://127.0.0.1:8000/api/admin/admins/destory/' + id)
            .then(response => {
                this.getAdmins();
                this.getUsers();
            });
        },

        // delete admin by id
        getUserUpdate(id){
            this.isEdit = 1;
            axios.get('http://127.0.0.1:8000/api/admin/users/' + id)
            .then(response => {
                this.typeUpID = response.data.type_id;
                this.idUpdate = id;
            });
        },

        // update type of users
        submitForm(){
            let formData = new FormData();  // new form data
            if(this.select == '' || this.idUpdate == '')
            {
                alert('Must not be empty'); return 0;
            }
            formData.append("type_id", this.select);

            // store From Url POST api/admin/products
            axios.post('http://127.0.0.1:8000/api/admin/users/type/' + this.idUpdate, formData)
                    .then((res) => {
                        alert("done change type");
                        this.isEdit = 0; this.select = '';
                        this.getUsers();
                    })
                    .catch((error) => {
                        alert("There is Error When update Type");
            });
        },

    }
}
</script>
