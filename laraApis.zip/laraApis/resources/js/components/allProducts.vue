<template>
<div class="container">
<div class="d-flex mt-2"><span class="w-100">My Products</span>  <button class="btn btn-success" @click="isAdd = 1">+</button></div>

    <table class="table" width="100%" >
        <thead>
        <tr>
            <th scope="col">id</th>
            <th scope="col">name</th>
            <th scope="col">image</th>
            <th scope="col">price</th>
            <th scope="col">active</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="porduct in porducts.data" :key="porduct.id">
            <td scope="row">{{ porduct.id }}</td>
            <td>{{ porduct.name }}</td>
            <td><img :src="porduct.image" alt="img" width="70"></td>
            <td>
                <span style="margin: 0px 5px;" v-for="(prc , index) in porduct.price" :key="prc.id">
                    {{ types[index-1].name }} => {{ prc }} :
                </span>
            </td>
            <td>{{ porduct.active }}</td>
            <td>
                <button @click="deleteProduct(porduct.id)" class="btn btn-danger">Delete</button>
                <a :href="'home/edit/'+porduct.id" class="btn btn-primary">Edit</a>
            </td>
        </tr>
        </tbody>
    </table>
    <pagination :data="porducts" @pagination-change-page="getProducts"></pagination>


    <div class="position-fixed end-0 top-0 bottom-0 bg-warning p-2 overflow-auto" v-if="isAdd == 1">
        <p><button class="btn btn-danger float-end" @click="isAdd = 0">X</button></p>
        <hr>
        <p class="text-center fw-bold text-coca">New Product</p>
        <form @submit.prevent="submitForm">

            <div class="input-group mt-3">
                <span class="input-group-text">Name</span>
                <input type="text" name="name" class="form-control" placeholder="Name...." v-model="name">
            </div>

            <hr>

            <div class="input-group mt-3">
                <span class="input-group-text">Normal</span>
                <input type="text" name="normal" class="form-control" placeholder="normal...." v-model="normal">
            </div>

            <div class="input-group mt-3">
                <span class="input-group-text">Silver</span>
                <input type="text" name="silver" class="form-control" placeholder="silver...." v-model="silver">
            </div>

            <div class="input-group mt-3">
                <span class="input-group-text">Gold</span>
                <input type="text" name="gold" class="form-control" placeholder="gold...." v-model="gold">
            </div>


            <div class="form-check mt-2">
                <input class="form-check-input" type="checkbox" name="active" @change="active? active = 1 : active = 0" id="availableCheck" v-model="active">
                <label class="form-check-label" for="availableCheck">
                    Active
                </label>
            </div>

            <hr>

            <label for="headerImage" class="form-label"> Add new Image</label>
            <div class="d-flex flex-row">
                <div class="flex-grow-1">
                    <input class="form-control form-control-lg" name="image" type="file" placeholder="Add Image" @change="onFileChange">
                </div>
            </div>


            <div class="w-100 text-center mt-2">
                <button type="submit" class="btn btn-success">Add</button>
            </div>

        </form>

    </div>


</div>
</template>

<script>
    export default {
        data(){
            return {
                isAdd : 0,
                porducts:{},
                types:{},
                name : '',
                gold : '',
                silver : '',
                normal : '',
                active : 1,
                image : '',
                page : 1
            }
        },
        mounted() {
            axios.get('http://localhost:8080/laraApis/public/api/admin/types')
            .then(response => {
                this.types = response.data;
            });
        this.getProducts();
        },
        methods:{
            getProducts(page = 1) {
                this.page = page;
            axios.get('http://127.0.0.1:8000/api/admin/products/pages?page=' + page)
                    .then(response => {
                        this.porducts = response.data.data;
                    });
            },
            //add image file to image
            onFileChange(e) {
                this.image = e.target.files[0];
            },
            // add new product
            submitForm(){
                let formData = new FormData();  // new form data
                if(this.name == '' || this.gold == '' || this.silver == '' || this.normal == '')
                {
                    alert('Must not be empty'); return 0;
                }
                formData.append("name", this.name);
                formData.append("gold", this.gold);
                formData.append("silver", this.silver);
                formData.append("normal", this.normal);
                formData.append("active", this.active);
                formData.append("image", this.image);

                // store From Url POST api/admin/products
                axios.post('http://127.0.0.1:8000/api/admin/products', formData)
                        .then((res) => {
                            alert(res.data.msg);
                            this.name= ''; this.gold= ''; this.silver= ''; this.normal= ''; this.active= 1; this.image = '';
                            this.isAdd = 0;
                            this.getProducts(this.page);
                        })
                        .catch((error) => {
                            alert("There is Error When Add Product");
                });
            },

            //delete product
            deleteProduct(id){
                //delet product from url POST api/admin/products/destroy/{id}
                axios.post('http://127.0.0.1:8000/api/admin/products/destroy/' + id)
                        .then((res) => {
                            this.getProducts(this.page);
                            alert(res.data.msg);
                        })
                        .catch((error) => {
                            console.log(id);
                            });


            }
        }
    }
</script>
