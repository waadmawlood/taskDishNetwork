<?php

use App\Http\Controllers\api\PassportAuthController;
use App\Http\Controllers\api\ProductController;
use App\Http\Controllers\api\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Laravel\Passport\Passport;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/



//guest
Route::group(['middleware'=>['api'],'namespace'=>'api',"as"=>"userGuest."],function () {
    Route::post('register', [PassportAuthController::class, 'register'])->name('register'); //---Api register
    Route::post('login', [PassportAuthController::class, 'login'])->name('login'); //------------Api Login

    Route::get('types',[UserController::class,'getTypes']); //--Api get types
});





//Auth
Route::group(['middleware'=>['auth:api'],'namespace'=>'api',"as"=>"userAuth."],function () {
    Route::get('user', [PassportAuthController::class, 'userProfile']);//------------------------API get user
    Route::post('user/update', [UserController::class, 'userUpdate'])->name('user');//------------------------API update som information
    Route::post('logout', [PassportAuthController::class,'logout'])->name('logout'); //----------API loguot
    Route::get('token', [PassportAuthController::class,'token'])->name('token'); //--------------API get access token

    Route::get('products/pages', [ProductController::class,'getPages'])->name('products.pages'); //---API get products paginate
    Route::get('products', [ProductController::class,'index'])->name('products'); //--------------API get all products
    Route::get('products/{id}', [ProductController::class,'show'])->name('show'); //--------------API get product : id
    Route::post('products', [ProductController::class,'store'])->name('store');   //--------------API store (create) product
    Route::post('products/{id}', [ProductController::class,'update'])->name('update'); //---------API update product
    Route::post('products/destroy/{id}', [ProductController::class,'destroy'])->name('destroy'); //-API delete product
});
