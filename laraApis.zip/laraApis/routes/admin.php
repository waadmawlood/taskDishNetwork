<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\UserController;
use App\Http\Controllers\api\PassportAuthController;
use App\Http\Controllers\api\ProductController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//admin routes  Need auth web


Route::group(['namespace'=>'api',"as"=>"admin."],function () {


    Route::get('users', [UserController::class,'index'])->name('users'); //--------------API get all users
    Route::get('admins', [UserController::class,'getAdmins'])->name('admins'); //--------------API get admins only
    Route::get('users/{id}', [UserController::class,'find'])->name('user'); //--------------API user : id
    Route::post('users/type/{id}', [UserController::class,'changeType'])->name('user.type'); //--------API change type user : id
    Route::post('admins/create/{id}', [UserController::class,'addAdmin'])->name('admins.create'); //-----API add user admin role
    Route::post('admins/destory/{id}', [UserController::class,'deleteAdmin'])->name('admins.destory'); //-----API remove user admin role

    Route::get('types',[UserController::class,'getTypes']); //--Api Lang if send lang

    Route::get('products/pages', [ProductController::class,'getPages'])->name('products.pages'); //----API get products paginate
    Route::get('products', [ProductController::class,'index'])->name('products'); //--------------API get all products
    Route::get('products/{id}', [ProductController::class,'showAdmin'])->name('show'); //--------------API get product : id
    Route::post('products', [ProductController::class,'store'])->name('store'); //--------------API store (create) product
    Route::post('products/{id}', [ProductController::class,'update'])->name('update'); //-----------API update product
    Route::post('products/destroy/{id}', [ProductController::class,'destroy'])->name('destroy'); //------API delete product

});

